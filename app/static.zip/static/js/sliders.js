function back_end() {
    document.getElementById("back_end_info").innerHTML = document.getElementById("back_end_range").value.toString() + "%";
}

function front_end() {
    document.getElementById("front_end_info").innerHTML = document.getElementById("front_end_range").value.toString() + "%";
}

function git_foo() {
    document.getElementById("git_foo_info").innerHTML = document.getElementById("git_foo_range").value.toString() + "%";
}